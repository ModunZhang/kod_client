class ColumnHeaders:
    msgctxt = 'Message context'
    msgid = 'Message id'
    comment = 'Source comment'
    tcomment = 'Translator comment'
    occurrences = 'References'
